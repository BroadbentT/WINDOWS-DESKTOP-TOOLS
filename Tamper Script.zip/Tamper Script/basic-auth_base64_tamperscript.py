import base64

def tamper(payload, **kwargs):
# NTLM
#    auth = b'domain\:username:' + payload.encode()	 # Inject into password
#    auth = b'domain\:' + payload.encode() + b':password'# Inject into username
    auth = payload.encode() + b'\:username:password'	 # Inject into domain

# BASIC
#    auth = payload.encode() + b':password' 		 # Inject into username
#    auth = b'username:' + payload.encode() 		 # Inject into password
    return base64.b64encode(auth).decode()
