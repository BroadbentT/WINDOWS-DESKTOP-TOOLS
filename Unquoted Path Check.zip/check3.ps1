$Services = Get-CimInstance Win32_Service |
Where-Object {
    $_.PathName -and
    $_.PathName -notmatch '^"' -and
    $_.PathName -match '\s' -and
    $_.PathName -match '\s.*\.exe'
} |
Select-Object Name,
DisplayName,
StartName,
StartMode,
PathName

$Services | Format-List