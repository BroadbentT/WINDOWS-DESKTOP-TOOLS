$Directory = Read-Host "Enter the directory to check"

[PSCustomObject]@{
    Path = $Directory
    Writable = try {
        if (-not (Test-Path -LiteralPath $Directory -PathType Container)) {
            throw "Directory does not exist"
        }

        $test = Join-Path $Directory ([guid]::NewGuid().ToString() + '.tmp')
        New-Item -ItemType File -Path $test -ErrorAction Stop | Out-Null
        Remove-Item $test -Force -ErrorAction Stop
        $true
    } catch {
        $false
    }
}