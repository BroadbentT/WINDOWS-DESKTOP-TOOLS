import ctypes
import os

# Define the license string exactly as provided by the vendor
LICENSE_STRING = (
    "23 i2.ibase.base ni long normal standalone excl infinite_keys "
    "infinite_keys never never nil slm_code demo nil nil ni nil nil "
    "infinite_mins nil 0 ny8cygnsj/kjdnzn1xsflfsiegth1gpgp75z+s8w..." 
    "#aid=99f77d43-5c19-48fc-9621-b28567950002"
)

def verify_sentinel_license(lic_str):
    """
    Validates a Sentinel RMS license string signature using the 
    native Sentinel Licensing Library (lsapi).
    """
    # Load the native Sentinel RMS client library (lsapi32.dll or liblsapi.so)
    # The library contains the hardcoded vendor public key needed to check the signature
    try:
        if os.name == 'nt':
            sntl_lib = ctypes.CDLL("lsapi32.dll")
        else:
            sntl_lib = ctypes.CDLL("liblsapi.so")
    except OSError:
        print("[-] Error: Sentinel RMS Client Library (lsapi) not found on this system.")
        print("[!] You must install the i2 Licensing Runtime Environment to run this verification.")
        return False

    print("[*] Sentinel RMS library loaded successfully.")
    print("[*] Passing license string to cryptographic verification engine...")
    
    # Sentinel API typically uses VLSaddLicense or sntl_licensing_install
    # to cryptographically parse, check hashes, and verify signatures.
    sntl_lib.VLSaddLicense.argtypes = [ctypes.c_char_p]
    sntl_lib.VLSaddLicense.restype = ctypes.c_int
    
    # Execute verification
    status = sntl_lib.VLSaddLicense(lic_str.encode('utf-8'))
    
    # Return codes based on Thales Sentinel SDK documentation
    VLS_SUCCESS = 0
    VLS_FAIL = -1
    
    if status == VLS_SUCCESS:
        print("[+] Signature Verified: The cryptographic hash matches. The key has NOT been tampered with.")
        return True
    else:
        print(f"[-] Verification Failed (Error Code: {status}). The signature is invalid or tampered with.")
        return False

if __name__ == "__main__":
    verify_sentinel_license(LICENSE_STRING)